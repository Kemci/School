package week3;

// create class student
public class Student {

    String name;         // declare variable for student name
    String matricNumber; // declare variable for student Matric Number
    double gpa;          // declare variable for student gpa

    // go back to Main file and
    // - create an object of this class (student)
}
